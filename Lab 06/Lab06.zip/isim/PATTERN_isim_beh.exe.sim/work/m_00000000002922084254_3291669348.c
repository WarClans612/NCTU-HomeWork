/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Pelajaran/Program/Verilog/Digital Circuit Lab/Lab 06/Lab06/Time_Pattern.v";
static const char *ng1 = "----------------------------------------------------------------------------------------------------------------------";
static const char *ng2 = "                                                  Congratulations!                \t\t\t\t\t\t            ";
static const char *ng3 = "                                           You have passed all patterns!          \t\t\t\t\t\t            ";
static const char *ng4 = "                                           Your execution cycles = %5d cycles   \t\t\t\t\t\t            ";
static const char *ng5 = "                                           Your clock period = %.1f ns        \t\t\t\t\t                ";
static const char *ng6 = "                                           Your total latency = %.1f ns         \t\t\t\t\t\t            ";
static int ng7[] = {1, 0};
static int ng8[] = {0, 0};
static const char *ng9 = "--------------------------------------------------------------------------------------------------------------------------------------------";
static const char *ng10 = "                                                                        FAIL!                                                               ";
static const char *ng11 = "                                                  Output signal should be 0 after initial RESET at %t                                 ";
static unsigned int ng12[] = {9U, 0U};
static int ng13[] = {1024, 0};
static int ng14[] = {64, 0};
static int ng15[] = {16, 0};
static unsigned int ng16[] = {0U, 0U};
static unsigned int ng17[] = {1U, 0U};
static int ng18[] = {2, 0};
static unsigned int ng19[] = {2U, 0U};
static int ng20[] = {3, 0};
static unsigned int ng21[] = {3U, 0U};
static int ng22[] = {4, 0};
static unsigned int ng23[] = {4U, 0U};
static int ng24[] = {5, 0};
static int ng25[] = {6, 0};
static int ng26[] = {7, 0};
static int ng27[] = {8, 0};
static unsigned int ng28[] = {4294967295U, 4294967295U};
static int ng29[] = {10, 0};
static const char *ng30 = "                                                     The execution latency are over 10   cycles                                            ";
static const char *ng31 = "                                                       outvalid is more than 1 cycles                                                   ";
static int ng32[] = {9, 0};
static const char *ng33 = "                                                                PATTERN NO.%4d                                                           ";
static const char *ng34 = "                                                     Ans(value): %d,  Your output : %d  at %8t                                              ";
static int ng35[] = {100, 0};
static const char *ng36 = "you pass NO.%d PATTERN";



static int sp_PASS(char *t1, char *t2)
{
    char t9[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    double t8;
    char *t10;
    char *t11;
    double t12;
    double t13;
    char *t14;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2344);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(90, ng0);

LAB5:    xsi_set_current_line(91, ng0);
    t5 = (t1 + 2344);
    xsi_vlogfile_write(1, 0, 0, ng1, 1, t5);
    xsi_set_current_line(92, ng0);
    t4 = (t1 + 2344);
    xsi_vlogfile_write(1, 0, 0, ng2, 1, t4);
    xsi_set_current_line(93, ng0);
    t4 = (t1 + 2344);
    xsi_vlogfile_write(1, 0, 0, ng3, 1, t4);
    xsi_set_current_line(94, ng0);
    t4 = (t1 + 6928);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 2344);
    xsi_vlogfile_write(1, 0, 0, ng4, 2, t7, (char)119, t6, 32);
    xsi_set_current_line(95, ng0);
    t4 = (t1 + 6768);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = *((double *)t6);
    *((double *)t9) = t8;
    t7 = (t1 + 2344);
    xsi_vlogfile_write(1, 0, 0, ng5, 2, t7, (char)114, t9, 64);
    xsi_set_current_line(96, ng0);
    t4 = (t1 + 6928);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = xsi_vlog_convert_to_real(t6, 32, 1);
    t7 = (t1 + 6768);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    t12 = *((double *)t11);
    t13 = (t8 * t12);
    *((double *)t9) = t13;
    t14 = (t1 + 2344);
    xsi_vlogfile_write(1, 0, 0, ng6, 2, t14, (char)114, t9, 64);
    xsi_set_current_line(97, ng0);
    t4 = (t1 + 2344);
    xsi_vlogfile_write(1, 0, 0, ng1, 1, t4);
    xsi_set_current_line(98, ng0);
    xsi_vlog_finish(1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static int sp_reset_signal_task(char *t1, char *t2)
{
    char t7[8];
    char t9[8];
    char t24[8];
    char t25[8];
    char t33[8];
    char t68[16];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;
    char *t38;
    char *t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    char *t47;
    char *t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    char *t67;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2776);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(107, ng0);

LAB5:    xsi_set_current_line(108, ng0);
    t5 = (t2 + 56U);
    t6 = *((char **)t5);
    xsi_process_wait(t6, 500LL);
    *((char **)t3) = &&LAB6;
    t0 = 1;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(108, ng0);
    t4 = ((char*)((ng7)));
    t5 = (t1 + 6288);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(110, ng0);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    xsi_process_wait(t5, 2000LL);
    *((char **)t3) = &&LAB7;
    t0 = 1;
    goto LAB1;

LAB7:    xsi_set_current_line(111, ng0);
    t4 = (t1 + 5568U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng8)));
    memset(t7, 0, 8);
    if (*((unsigned int *)t5) != *((unsigned int *)t4))
        goto LAB9;

LAB8:    t6 = (t5 + 4);
    t8 = (t4 + 4);
    if (*((unsigned int *)t6) != *((unsigned int *)t8))
        goto LAB9;

LAB10:    memset(t9, 0, 8);
    t10 = (t7 + 4);
    t11 = *((unsigned int *)t10);
    t12 = (~(t11));
    t13 = *((unsigned int *)t7);
    t14 = (t13 & t12);
    t15 = (t14 & 1U);
    if (t15 != 0)
        goto LAB11;

LAB12:    if (*((unsigned int *)t10) != 0)
        goto LAB13;

LAB14:    t17 = (t9 + 4);
    t18 = *((unsigned int *)t9);
    t19 = (!(t18));
    t20 = *((unsigned int *)t17);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB15;

LAB16:    memcpy(t33, t9, 8);

LAB17:    t61 = (t33 + 4);
    t62 = *((unsigned int *)t61);
    t63 = (~(t62));
    t64 = *((unsigned int *)t33);
    t65 = (t64 & t63);
    t66 = (t65 != 0);
    if (t66 > 0)
        goto LAB25;

LAB26:
LAB27:    xsi_set_current_line(121, ng0);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    xsi_process_wait(t5, 10000LL);
    *((char **)t3) = &&LAB29;
    t0 = 1;
    goto LAB1;

LAB9:    *((unsigned int *)t7) = 1;
    goto LAB10;

LAB11:    *((unsigned int *)t9) = 1;
    goto LAB14;

LAB13:    t16 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t16) = 1;
    goto LAB14;

LAB15:    t22 = (t1 + 5728U);
    t23 = *((char **)t22);
    t22 = ((char*)((ng8)));
    memset(t24, 0, 8);
    xsi_vlog_signed_case_noteq(t24, 32, t23, 16, t22, 32);
    memset(t25, 0, 8);
    t26 = (t24 + 4);
    t27 = *((unsigned int *)t26);
    t28 = (~(t27));
    t29 = *((unsigned int *)t24);
    t30 = (t29 & t28);
    t31 = (t30 & 1U);
    if (t31 != 0)
        goto LAB18;

LAB19:    if (*((unsigned int *)t26) != 0)
        goto LAB20;

LAB21:    t34 = *((unsigned int *)t9);
    t35 = *((unsigned int *)t25);
    t36 = (t34 | t35);
    *((unsigned int *)t33) = t36;
    t37 = (t9 + 4);
    t38 = (t25 + 4);
    t39 = (t33 + 4);
    t40 = *((unsigned int *)t37);
    t41 = *((unsigned int *)t38);
    t42 = (t40 | t41);
    *((unsigned int *)t39) = t42;
    t43 = *((unsigned int *)t39);
    t44 = (t43 != 0);
    if (t44 == 1)
        goto LAB22;

LAB23:
LAB24:    goto LAB17;

LAB18:    *((unsigned int *)t25) = 1;
    goto LAB21;

LAB20:    t32 = (t25 + 4);
    *((unsigned int *)t25) = 1;
    *((unsigned int *)t32) = 1;
    goto LAB21;

LAB22:    t45 = *((unsigned int *)t33);
    t46 = *((unsigned int *)t39);
    *((unsigned int *)t33) = (t45 | t46);
    t47 = (t9 + 4);
    t48 = (t25 + 4);
    t49 = *((unsigned int *)t47);
    t50 = (~(t49));
    t51 = *((unsigned int *)t9);
    t52 = (t51 & t50);
    t53 = *((unsigned int *)t48);
    t54 = (~(t53));
    t55 = *((unsigned int *)t25);
    t56 = (t55 & t54);
    t57 = (~(t52));
    t58 = (~(t56));
    t59 = *((unsigned int *)t39);
    *((unsigned int *)t39) = (t59 & t57);
    t60 = *((unsigned int *)t39);
    *((unsigned int *)t39) = (t60 & t58);
    goto LAB24;

LAB25:    xsi_set_current_line(111, ng0);

LAB28:    xsi_set_current_line(113, ng0);
    t67 = (t1 + 2776);
    xsi_vlogfile_write(1, 0, 0, ng9, 1, t67);
    xsi_set_current_line(114, ng0);
    t4 = (t1 + 2776);
    xsi_vlogfile_write(1, 0, 0, ng10, 1, t4);
    xsi_set_current_line(115, ng0);
    t4 = xsi_vlog_time(t68, 1000.0000000000000, 100.00000000000000);
    t5 = (t1 + 2776);
    xsi_vlogfile_write(1, 0, 0, ng11, 2, t5, (char)118, t68, 64);
    xsi_set_current_line(116, ng0);
    t4 = (t1 + 2776);
    xsi_vlogfile_write(1, 0, 0, ng9, 1, t4);
    xsi_set_current_line(119, ng0);
    xsi_vlog_finish(1);
    goto LAB27;

LAB29:    xsi_set_current_line(121, ng0);
    t4 = ((char*)((ng8)));
    t5 = (t1 + 6288);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    goto LAB4;

}

static int sp_random_task(char *t1, char *t2)
{
    char t8[8];
    char t11[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 3208);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(126, ng0);

LAB5:    xsi_set_current_line(128, ng0);
    t5 = (t1 + 8048);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t8) = xsi_vlog_rtl_dist_uniform(1, t7, -2147483648, 2147483647);
    t9 = (t8 + 4);
    *((int *)t9) = 0;
    t10 = ((char*)((ng12)));
    memset(t11, 0, 8);
    xsi_vlog_unsigned_mod(t11, 32, t8, 32, t10, 32);
    t12 = (t1 + 8528);
    xsi_vlogvar_assign_value(t12, t11, 0, 0, 4);
    xsi_set_current_line(130, ng0);
    t4 = (t1 + 7408);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((int *)t8) = xsi_vlog_rtl_dist_uniform(1, t6, -2147483648, 2147483647);
    t7 = (t8 + 4);
    *((int *)t7) = 0;
    t9 = ((char*)((ng13)));
    memset(t11, 0, 8);
    xsi_vlog_signed_mod(t11, 32, t8, 32, t9, 32);
    t10 = (t1 + 9488);
    xsi_vlogvar_assign_value(t10, t11, 0, 0, 10);
    xsi_set_current_line(131, ng0);
    t4 = (t1 + 7408);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((int *)t8) = xsi_vlog_rtl_dist_uniform(1, t6, -2147483648, 2147483647);
    t7 = (t8 + 4);
    *((int *)t7) = 0;
    t9 = ((char*)((ng14)));
    memset(t11, 0, 8);
    xsi_vlog_signed_mod(t11, 32, t8, 32, t9, 32);
    t10 = (t1 + 8848);
    xsi_vlogvar_assign_value(t10, t11, 0, 0, 6);
    xsi_set_current_line(132, ng0);
    t4 = (t1 + 7408);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((int *)t8) = xsi_vlog_rtl_dist_uniform(1, t6, -2147483648, 2147483647);
    t7 = (t8 + 4);
    *((int *)t7) = 0;
    t9 = ((char*)((ng14)));
    memset(t11, 0, 8);
    xsi_vlog_signed_mod(t11, 32, t8, 32, t9, 32);
    t10 = (t1 + 9008);
    xsi_vlogvar_assign_value(t10, t11, 0, 0, 6);
    xsi_set_current_line(133, ng0);
    t4 = (t1 + 7408);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((int *)t8) = xsi_vlog_rtl_dist_uniform(1, t6, -2147483648, 2147483647);
    t7 = (t8 + 4);
    *((int *)t7) = 0;
    t9 = ((char*)((ng15)));
    memset(t11, 0, 8);
    xsi_vlog_signed_mod(t11, 32, t8, 32, t9, 32);
    t10 = (t1 + 9168);
    xsi_vlogvar_assign_value(t10, t11, 0, 0, 4);
    xsi_set_current_line(135, ng0);
    t4 = (t1 + 8528);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);

LAB6:    t7 = ((char*)((ng8)));
    t13 = xsi_vlog_unsigned_case_compare(t6, 4, t7, 32);
    if (t13 == 1)
        goto LAB7;

LAB8:    t4 = ((char*)((ng7)));
    t13 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t13 == 1)
        goto LAB9;

LAB10:    t4 = ((char*)((ng18)));
    t13 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t13 == 1)
        goto LAB11;

LAB12:    t4 = ((char*)((ng20)));
    t13 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t13 == 1)
        goto LAB13;

LAB14:    t4 = ((char*)((ng22)));
    t13 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t13 == 1)
        goto LAB15;

LAB16:    t4 = ((char*)((ng24)));
    t13 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t13 == 1)
        goto LAB17;

LAB18:    t4 = ((char*)((ng25)));
    t13 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t13 == 1)
        goto LAB19;

LAB20:    t4 = ((char*)((ng26)));
    t13 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t13 == 1)
        goto LAB21;

LAB22:    t4 = ((char*)((ng27)));
    t13 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t13 == 1)
        goto LAB23;

LAB24:
LAB25:    xsi_set_current_line(148, ng0);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t2 + 56U);
    t9 = *((char **)t7);
    xsi_vlog_subprograminvocation_setJumpstate(t2, t9, &&LAB31);
    t10 = (t2 + 56U);
    t12 = *((char **)t10);
    t14 = (t1 + 3640);
    t15 = xsi_create_subprogram_invocation(t12, 0, t1, t14, 0, t2);
    xsi_vlog_subprogram_pushinvocation(t14, t15);

LAB33:    t16 = (t2 + 64U);
    t17 = *((char **)t16);
    t18 = (t17 + 80U);
    t19 = *((char **)t18);
    t20 = (t19 + 272U);
    t21 = *((char **)t20);
    t22 = (t21 + 0U);
    t23 = *((char **)t22);
    t13 = ((int  (*)(char *, char *))t23)(t1, t17);
    if (t13 == -1)
        goto LAB34;

LAB35:    if (t13 != 0)
        goto LAB36;

LAB31:    t17 = (t1 + 3640);
    xsi_vlog_subprogram_popinvocation(t17);

LAB32:    t24 = (t2 + 64U);
    t25 = *((char **)t24);
    t24 = (t1 + 3640);
    t26 = (t2 + 56U);
    t27 = *((char **)t26);
    xsi_delete_subprogram_invocation(t24, t25, t1, t27, t2);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
LAB7:    xsi_set_current_line(136, ng0);

LAB26:    xsi_set_current_line(136, ng0);
    t9 = ((char*)((ng8)));
    t10 = (t1 + 8688);
    xsi_vlogvar_assign_value(t10, t9, 0, 0, 3);
    xsi_set_current_line(136, ng0);
    t4 = ((char*)((ng16)));
    t5 = (t1 + 9328);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 4);
    goto LAB25;

LAB9:    xsi_set_current_line(137, ng0);

LAB27:    xsi_set_current_line(137, ng0);
    t5 = ((char*)((ng8)));
    t7 = (t1 + 8688);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 3);
    xsi_set_current_line(137, ng0);
    t4 = ((char*)((ng17)));
    t5 = (t1 + 9328);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 4);
    goto LAB25;

LAB11:    xsi_set_current_line(138, ng0);

LAB28:    xsi_set_current_line(138, ng0);
    t5 = ((char*)((ng8)));
    t7 = (t1 + 8688);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 3);
    xsi_set_current_line(138, ng0);
    t4 = ((char*)((ng19)));
    t5 = (t1 + 9328);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 4);
    goto LAB25;

LAB13:    xsi_set_current_line(139, ng0);

LAB29:    xsi_set_current_line(139, ng0);
    t5 = ((char*)((ng8)));
    t7 = (t1 + 8688);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 3);
    xsi_set_current_line(139, ng0);
    t4 = ((char*)((ng21)));
    t5 = (t1 + 9328);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 4);
    goto LAB25;

LAB15:    xsi_set_current_line(140, ng0);

LAB30:    xsi_set_current_line(140, ng0);
    t5 = ((char*)((ng8)));
    t7 = (t1 + 8688);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 3);
    xsi_set_current_line(140, ng0);
    t4 = ((char*)((ng23)));
    t5 = (t1 + 9328);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 4);
    goto LAB25;

LAB17:    xsi_set_current_line(141, ng0);
    t5 = ((char*)((ng17)));
    t7 = (t1 + 8688);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 3);
    goto LAB25;

LAB19:    xsi_set_current_line(142, ng0);
    t5 = ((char*)((ng19)));
    t7 = (t1 + 8688);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 3);
    goto LAB25;

LAB21:    xsi_set_current_line(143, ng0);
    t5 = ((char*)((ng21)));
    t7 = (t1 + 8688);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 3);
    goto LAB25;

LAB23:    xsi_set_current_line(144, ng0);
    t5 = ((char*)((ng23)));
    t7 = (t1 + 8688);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 3);
    goto LAB25;

LAB34:    t0 = -1;
    goto LAB1;

LAB36:    t16 = (t2 + 48U);
    *((char **)t16) = &&LAB33;
    goto LAB1;

}

static int sp_execution(char *t1, char *t2)
{
    char t16[8];
    char t18[8];
    char t24[8];
    char t28[8];
    char t29[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t17;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t25;
    char *t26;
    char *t27;
    char *t30;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 3640);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(153, ng0);

LAB5:    xsi_set_current_line(155, ng0);
    t5 = (t1 + 8528);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);

LAB6:    t8 = ((char*)((ng8)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t8, 32);
    if (t9 == 1)
        goto LAB7;

LAB8:    t4 = ((char*)((ng7)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t4, 32);
    if (t9 == 1)
        goto LAB9;

LAB10:    t4 = ((char*)((ng18)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t4, 32);
    if (t9 == 1)
        goto LAB11;

LAB12:    t4 = ((char*)((ng20)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t4, 32);
    if (t9 == 1)
        goto LAB13;

LAB14:    t4 = ((char*)((ng22)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t4, 32);
    if (t9 == 1)
        goto LAB15;

LAB16:    t4 = ((char*)((ng24)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t4, 32);
    if (t9 == 1)
        goto LAB17;

LAB18:    t4 = ((char*)((ng25)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t4, 32);
    if (t9 == 1)
        goto LAB19;

LAB20:    t4 = ((char*)((ng26)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t4, 32);
    if (t9 == 1)
        goto LAB21;

LAB22:    t4 = ((char*)((ng27)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t4, 32);
    if (t9 == 1)
        goto LAB23;

LAB24:
LAB25:
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
LAB7:    xsi_set_current_line(156, ng0);
    t10 = (t1 + 8848);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t1 + 9008);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memset(t16, 0, 8);
    xsi_vlog_signed_bit_and(t16, 16, t12, 6, t15, 6);
    t17 = (t1 + 8368);
    xsi_vlogvar_assign_value(t17, t16, 0, 0, 16);
    goto LAB25;

LAB9:    xsi_set_current_line(157, ng0);
    t5 = (t1 + 8848);
    t6 = (t5 + 56U);
    t8 = *((char **)t6);
    t10 = (t1 + 9008);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memset(t16, 0, 8);
    xsi_vlog_signed_bit_or(t16, 16, t8, 6, t12, 6);
    t13 = (t1 + 8368);
    xsi_vlogvar_assign_value(t13, t16, 0, 0, 16);
    goto LAB25;

LAB11:    xsi_set_current_line(158, ng0);
    t5 = (t1 + 8848);
    t6 = (t5 + 56U);
    t8 = *((char **)t6);
    t10 = (t1 + 9008);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memset(t16, 0, 8);
    xsi_vlog_signed_bit_xor(t16, 16, t8, 6, t12, 6);
    t13 = (t1 + 8368);
    xsi_vlogvar_assign_value(t13, t16, 0, 0, 16);
    goto LAB25;

LAB13:    xsi_set_current_line(159, ng0);
    t5 = (t1 + 8848);
    t6 = (t5 + 56U);
    t8 = *((char **)t6);
    t10 = (t1 + 9008);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memset(t16, 0, 8);
    xsi_vlog_signed_add(t16, 16, t8, 6, t12, 6);
    t13 = (t1 + 8368);
    xsi_vlogvar_assign_value(t13, t16, 0, 0, 16);
    goto LAB25;

LAB15:    xsi_set_current_line(160, ng0);
    t5 = (t1 + 8848);
    t6 = (t5 + 56U);
    t8 = *((char **)t6);
    t10 = (t1 + 9008);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memset(t16, 0, 8);
    xsi_vlog_signed_minus(t16, 16, t8, 6, t12, 6);
    t13 = (t1 + 8368);
    xsi_vlogvar_assign_value(t13, t16, 0, 0, 16);
    goto LAB25;

LAB17:    xsi_set_current_line(161, ng0);

LAB26:    xsi_set_current_line(162, ng0);
    t5 = (t1 + 8848);
    t6 = (t5 + 56U);
    t8 = *((char **)t6);
    t10 = (t1 + 9008);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memset(t16, 0, 8);
    xsi_vlog_signed_multiply(t16, 16, t8, 6, t12, 6);
    t13 = (t1 + 9168);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memset(t18, 0, 8);
    xsi_vlog_signed_multiply(t18, 16, t16, 16, t15, 4);
    t17 = (t1 + 8368);
    xsi_vlogvar_assign_value(t17, t18, 0, 0, 16);
    goto LAB25;

LAB19:    xsi_set_current_line(164, ng0);

LAB27:    xsi_set_current_line(165, ng0);
    t5 = (t1 + 8848);
    t6 = (t5 + 56U);
    t8 = *((char **)t6);
    t10 = (t1 + 9008);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memset(t16, 0, 8);
    xsi_vlog_signed_add(t16, 16, t8, 6, t12, 6);
    t13 = (t1 + 9168);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memset(t18, 0, 8);
    xsi_vlog_signed_add(t18, 16, t16, 16, t15, 4);
    t17 = (t1 + 8848);
    t19 = (t17 + 56U);
    t20 = *((char **)t19);
    t21 = (t1 + 9008);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    memset(t24, 0, 8);
    xsi_vlog_signed_add(t24, 16, t20, 6, t23, 6);
    t25 = (t1 + 9168);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    memset(t28, 0, 8);
    xsi_vlog_signed_add(t28, 16, t24, 16, t27, 4);
    memset(t29, 0, 8);
    xsi_vlog_signed_multiply(t29, 16, t18, 16, t28, 16);
    t30 = (t1 + 8368);
    xsi_vlogvar_assign_value(t30, t29, 0, 0, 16);
    goto LAB25;

LAB21:    xsi_set_current_line(167, ng0);
    t5 = (t1 + 8848);
    t6 = (t5 + 56U);
    t8 = *((char **)t6);
    t10 = (t1 + 9488);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memset(t16, 0, 8);
    xsi_vlog_signed_add(t16, 16, t8, 6, t12, 10);
    t13 = (t1 + 8368);
    xsi_vlogvar_assign_value(t13, t16, 0, 0, 16);
    goto LAB25;

LAB23:    xsi_set_current_line(168, ng0);
    t5 = (t1 + 8848);
    t6 = (t5 + 56U);
    t8 = *((char **)t6);
    t10 = (t1 + 9488);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memset(t16, 0, 8);
    xsi_vlog_signed_minus(t16, 16, t8, 6, t12, 10);
    t13 = (t1 + 8368);
    xsi_vlogvar_assign_value(t13, t16, 0, 0, 16);
    goto LAB25;

}

static int sp_input_task(char *t1, char *t2)
{
    char t16[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 4072);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(179, ng0);

LAB5:    xsi_set_current_line(180, ng0);
    t5 = ((char*)((ng18)));
    t6 = (t5 + 4);
    t7 = *((unsigned int *)t6);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t1 + 14148);
    *((int *)t11) = t10;

LAB6:    t12 = (t1 + 14148);
    if (*((int *)t12) > 0)
        goto LAB7;

LAB8:    xsi_set_current_line(181, ng0);
    t4 = ((char*)((ng7)));
    t5 = (t1 + 6448);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(183, ng0);
    t4 = (t1 + 8528);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);

LAB10:    t11 = ((char*)((ng8)));
    t10 = xsi_vlog_unsigned_case_compare(t6, 4, t11, 32);
    if (t10 == 1)
        goto LAB11;

LAB12:    t4 = ((char*)((ng7)));
    t10 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t10 == 1)
        goto LAB13;

LAB14:    t4 = ((char*)((ng18)));
    t10 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t10 == 1)
        goto LAB15;

LAB16:    t4 = ((char*)((ng20)));
    t10 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t10 == 1)
        goto LAB17;

LAB18:    t4 = ((char*)((ng22)));
    t10 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t10 == 1)
        goto LAB19;

LAB20:    t4 = ((char*)((ng24)));
    t10 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t10 == 1)
        goto LAB21;

LAB22:    t4 = ((char*)((ng25)));
    t10 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t10 == 1)
        goto LAB23;

LAB24:    t4 = ((char*)((ng26)));
    t10 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t10 == 1)
        goto LAB25;

LAB26:    t4 = ((char*)((ng27)));
    t10 = xsi_vlog_unsigned_case_compare(t6, 4, t4, 32);
    if (t10 == 1)
        goto LAB27;

LAB28:
LAB29:    xsi_set_current_line(197, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t11 = (t5 + 16U);
    xsi_wp_set_status(t11, 1);
    *((char **)t3) = &&LAB30;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB7:    xsi_set_current_line(180, ng0);
    t13 = (t2 + 88U);
    t14 = *((char **)t13);
    t15 = (t14 + 0U);
    xsi_wp_set_status(t15, 1);
    *((char **)t3) = &&LAB9;
    goto LAB1;

LAB9:    t4 = (t1 + 14148);
    t10 = *((int *)t4);
    *((int *)t4) = (t10 - 1);
    goto LAB6;

LAB11:    xsi_set_current_line(184, ng0);
    t12 = (t1 + 9328);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t1 + 9008);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t19 = (t1 + 8848);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    t22 = (t1 + 8688);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    xsi_vlogtype_concat(t16, 19, 19, 4U, t24, 3, t21, 6, t18, 6, t14, 4);
    t25 = (t1 + 6608);
    xsi_vlogvar_assign_value(t25, t16, 0, 0, 19);
    goto LAB29;

LAB13:    xsi_set_current_line(185, ng0);
    t5 = (t1 + 9328);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    t13 = (t1 + 9008);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t17 = (t1 + 8848);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t20 = (t1 + 8688);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    xsi_vlogtype_concat(t16, 19, 19, 4U, t22, 3, t19, 6, t15, 6, t12, 4);
    t23 = (t1 + 6608);
    xsi_vlogvar_assign_value(t23, t16, 0, 0, 19);
    goto LAB29;

LAB15:    xsi_set_current_line(186, ng0);
    t5 = (t1 + 9328);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    t13 = (t1 + 9008);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t17 = (t1 + 8848);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t20 = (t1 + 8688);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    xsi_vlogtype_concat(t16, 19, 19, 4U, t22, 3, t19, 6, t15, 6, t12, 4);
    t23 = (t1 + 6608);
    xsi_vlogvar_assign_value(t23, t16, 0, 0, 19);
    goto LAB29;

LAB17:    xsi_set_current_line(187, ng0);
    t5 = (t1 + 9328);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    t13 = (t1 + 9008);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t17 = (t1 + 8848);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t20 = (t1 + 8688);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    xsi_vlogtype_concat(t16, 19, 19, 4U, t22, 3, t19, 6, t15, 6, t12, 4);
    t23 = (t1 + 6608);
    xsi_vlogvar_assign_value(t23, t16, 0, 0, 19);
    goto LAB29;

LAB19:    xsi_set_current_line(188, ng0);
    t5 = (t1 + 9328);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    t13 = (t1 + 9008);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t17 = (t1 + 8848);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t20 = (t1 + 8688);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    xsi_vlogtype_concat(t16, 19, 19, 4U, t22, 3, t19, 6, t15, 6, t12, 4);
    t23 = (t1 + 6608);
    xsi_vlogvar_assign_value(t23, t16, 0, 0, 19);
    goto LAB29;

LAB21:    xsi_set_current_line(189, ng0);
    t5 = (t1 + 9168);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    t13 = (t1 + 9008);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t17 = (t1 + 8848);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t20 = (t1 + 8688);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    xsi_vlogtype_concat(t16, 19, 19, 4U, t22, 3, t19, 6, t15, 6, t12, 4);
    t23 = (t1 + 6608);
    xsi_vlogvar_assign_value(t23, t16, 0, 0, 19);
    goto LAB29;

LAB23:    xsi_set_current_line(190, ng0);
    t5 = (t1 + 9168);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    t13 = (t1 + 9008);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t17 = (t1 + 8848);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t20 = (t1 + 8688);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    xsi_vlogtype_concat(t16, 19, 19, 4U, t22, 3, t19, 6, t15, 6, t12, 4);
    t23 = (t1 + 6608);
    xsi_vlogvar_assign_value(t23, t16, 0, 0, 19);
    goto LAB29;

LAB25:    xsi_set_current_line(191, ng0);
    t5 = (t1 + 9488);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    t13 = (t1 + 8848);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t17 = (t1 + 8688);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    xsi_vlogtype_concat(t16, 19, 19, 3U, t19, 3, t15, 6, t12, 10);
    t20 = (t1 + 6608);
    xsi_vlogvar_assign_value(t20, t16, 0, 0, 19);
    goto LAB29;

LAB27:    xsi_set_current_line(192, ng0);
    t5 = (t1 + 9488);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    t13 = (t1 + 8848);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t17 = (t1 + 8688);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    xsi_vlogtype_concat(t16, 19, 19, 3U, t19, 3, t15, 6, t12, 10);
    t20 = (t1 + 6608);
    xsi_vlogvar_assign_value(t20, t16, 0, 0, 19);
    goto LAB29;

LAB30:    xsi_set_current_line(201, ng0);
    t4 = ((char*)((ng8)));
    t5 = (t1 + 6448);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(202, ng0);
    t4 = ((char*)((ng28)));
    t5 = (t1 + 6608);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 19);
    goto LAB4;

}

static int sp_wait_out_valid(char *t1, char *t2)
{
    char t7[8];
    char t23[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    int t31;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 4504);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(208, ng0);

LAB5:    xsi_set_current_line(209, ng0);
    t5 = ((char*)((ng8)));
    t6 = (t1 + 7088);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 32);
    xsi_set_current_line(210, ng0);

LAB6:    t4 = (t1 + 5568U);
    t5 = *((char **)t4);
    memset(t7, 0, 8);
    t4 = (t5 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (~(t8));
    t10 = *((unsigned int *)t5);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t4) == 0)
        goto LAB7;

LAB9:    t6 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t6) = 1;

LAB10:    t13 = (t7 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t7);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB11;

LAB12:    xsi_set_current_line(226, ng0);
    t4 = (t1 + 6928);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 7088);
    t19 = (t13 + 56U);
    t20 = *((char **)t19);
    memset(t7, 0, 8);
    xsi_vlog_signed_add(t7, 32, t6, 32, t20, 32);
    t21 = (t1 + 6928);
    xsi_vlogvar_assign_value(t21, t7, 0, 0, 32);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
LAB7:    *((unsigned int *)t7) = 1;
    goto LAB10;

LAB11:    xsi_set_current_line(210, ng0);

LAB13:    xsi_set_current_line(213, ng0);
    t19 = (t1 + 7088);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    t22 = ((char*)((ng29)));
    memset(t23, 0, 8);
    xsi_vlog_signed_equal(t23, 32, t21, 32, t22, 32);
    t24 = (t23 + 4);
    t25 = *((unsigned int *)t24);
    t26 = (~(t25));
    t27 = *((unsigned int *)t23);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB14;

LAB15:
LAB16:    xsi_set_current_line(223, ng0);
    t4 = (t1 + 7088);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = ((char*)((ng7)));
    memset(t7, 0, 8);
    xsi_vlog_signed_add(t7, 32, t6, 32, t13, 32);
    t19 = (t1 + 7088);
    xsi_vlogvar_assign_value(t19, t7, 0, 0, 32);
    xsi_set_current_line(224, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 16U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB22;
    goto LAB1;

LAB14:    xsi_set_current_line(213, ng0);

LAB17:    xsi_set_current_line(215, ng0);
    t30 = (t1 + 4504);
    xsi_vlogfile_write(1, 0, 0, ng9, 1, t30);
    xsi_set_current_line(216, ng0);
    t4 = (t1 + 4504);
    xsi_vlogfile_write(1, 0, 0, ng10, 1, t4);
    xsi_set_current_line(217, ng0);
    t4 = (t1 + 4504);
    xsi_vlogfile_write(1, 0, 0, ng30, 1, t4);
    xsi_set_current_line(218, ng0);
    t4 = (t1 + 4504);
    xsi_vlogfile_write(1, 0, 0, ng9, 1, t4);
    xsi_set_current_line(220, ng0);
    t4 = ((char*)((ng18)));
    t5 = (t4 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (~(t8));
    t10 = *((unsigned int *)t4);
    t31 = (t10 & t9);
    t6 = (t1 + 14152);
    *((int *)t6) = t31;

LAB18:    t13 = (t1 + 14152);
    if (*((int *)t13) > 0)
        goto LAB19;

LAB20:    xsi_set_current_line(221, ng0);
    xsi_vlog_finish(1);
    goto LAB16;

LAB19:    xsi_set_current_line(220, ng0);
    t19 = (t2 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 0U);
    xsi_wp_set_status(t21, 1);
    *((char **)t3) = &&LAB21;
    goto LAB1;

LAB21:    t4 = (t1 + 14152);
    t31 = *((int *)t4);
    *((int *)t4) = (t31 - 1);
    goto LAB18;

LAB22:    goto LAB6;

}

static int sp_check_ans(char *t1, char *t2)
{
    char t15[8];
    char t24[16];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    int t23;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 4936);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(229, ng0);

LAB5:    xsi_set_current_line(231, ng0);
    t5 = ((char*)((ng8)));
    t6 = (t1 + 7088);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 32);
    xsi_set_current_line(232, ng0);

LAB6:    t4 = (t1 + 5568U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t7 = *((unsigned int *)t4);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB7;

LAB8:
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
LAB7:    xsi_set_current_line(232, ng0);

LAB9:    xsi_set_current_line(237, ng0);
    t6 = (t1 + 7088);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng8)));
    memset(t15, 0, 8);
    xsi_vlog_signed_greater(t15, 32, t13, 32, t14, 32);
    t16 = (t15 + 4);
    t17 = *((unsigned int *)t16);
    t18 = (~(t17));
    t19 = *((unsigned int *)t15);
    t20 = (t19 & t18);
    t21 = (t20 != 0);
    if (t21 > 0)
        goto LAB10;

LAB11:
LAB12:    xsi_set_current_line(250, ng0);
    t4 = (t1 + 5728U);
    t5 = *((char **)t4);
    t4 = (t1 + 8368);
    t6 = (t4 + 56U);
    t12 = *((char **)t6);
    memset(t15, 0, 8);
    xsi_vlog_signed_case_noteq(t15, 16, t5, 16, t12, 16);
    t13 = (t15 + 4);
    t7 = *((unsigned int *)t13);
    t8 = (~(t7));
    t9 = *((unsigned int *)t15);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB18;

LAB19:
LAB20:    xsi_set_current_line(270, ng0);
    t4 = (t1 + 7088);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = ((char*)((ng7)));
    memset(t15, 0, 8);
    xsi_vlog_signed_add(t15, 32, t6, 32, t12, 32);
    t13 = (t1 + 7088);
    xsi_vlogvar_assign_value(t13, t15, 0, 0, 32);
    xsi_set_current_line(271, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 32U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB26;
    goto LAB1;

LAB10:    xsi_set_current_line(237, ng0);

LAB13:    xsi_set_current_line(239, ng0);
    t22 = (t1 + 4936);
    xsi_vlogfile_write(1, 0, 0, ng9, 1, t22);
    xsi_set_current_line(240, ng0);
    t4 = (t1 + 4936);
    xsi_vlogfile_write(1, 0, 0, ng10, 1, t4);
    xsi_set_current_line(241, ng0);
    t4 = (t1 + 4936);
    xsi_vlogfile_write(1, 0, 0, ng31, 1, t4);
    xsi_set_current_line(242, ng0);
    t4 = (t1 + 4936);
    xsi_vlogfile_write(1, 0, 0, ng9, 1, t4);
    xsi_set_current_line(243, ng0);
    t4 = ((char*)((ng32)));
    t5 = (t4 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (~(t7));
    t9 = *((unsigned int *)t4);
    t23 = (t9 & t8);
    t6 = (t1 + 14156);
    *((int *)t6) = t23;

LAB14:    t12 = (t1 + 14156);
    if (*((int *)t12) > 0)
        goto LAB15;

LAB16:    xsi_set_current_line(244, ng0);
    xsi_vlog_finish(1);
    goto LAB12;

LAB15:    xsi_set_current_line(243, ng0);
    t13 = (t2 + 88U);
    t14 = *((char **)t13);
    t16 = (t14 + 0U);
    xsi_wp_set_status(t16, 1);
    *((char **)t3) = &&LAB17;
    goto LAB1;

LAB17:    t4 = (t1 + 14156);
    t23 = *((int *)t4);
    *((int *)t4) = (t23 - 1);
    goto LAB14;

LAB18:    xsi_set_current_line(250, ng0);

LAB21:    xsi_set_current_line(253, ng0);
    t14 = (t1 + 4936);
    xsi_vlogfile_write(1, 0, 0, ng9, 1, t14);
    xsi_set_current_line(254, ng0);
    t4 = (t1 + 4936);
    xsi_vlogfile_write(1, 0, 0, ng10, 1, t4);
    xsi_set_current_line(255, ng0);
    t4 = (t1 + 8208);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = ((char*)((ng7)));
    memset(t15, 0, 8);
    xsi_vlog_signed_add(t15, 32, t6, 32, t12, 32);
    t13 = (t1 + 4936);
    xsi_vlogfile_write(1, 0, 0, ng33, 2, t13, (char)119, t15, 32);
    xsi_set_current_line(256, ng0);
    t4 = (t1 + 8368);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t1 + 5728U);
    t13 = *((char **)t12);
    t12 = xsi_vlog_time(t24, 1000.0000000000000, 100.00000000000000);
    t14 = (t1 + 4936);
    xsi_vlogfile_write(1, 0, 0, ng34, 4, t14, (char)119, t6, 16, (char)119, t13, 16, (char)118, t24, 64);
    xsi_set_current_line(257, ng0);
    t4 = (t1 + 4936);
    xsi_vlogfile_write(1, 0, 0, ng9, 1, t4);
    xsi_set_current_line(259, ng0);
    t4 = ((char*)((ng32)));
    t5 = (t4 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (~(t7));
    t9 = *((unsigned int *)t4);
    t23 = (t9 & t8);
    t6 = (t1 + 14160);
    *((int *)t6) = t23;

LAB22:    t12 = (t1 + 14160);
    if (*((int *)t12) > 0)
        goto LAB23;

LAB24:    xsi_set_current_line(260, ng0);
    xsi_vlog_finish(1);
    goto LAB20;

LAB23:    xsi_set_current_line(259, ng0);
    t13 = (t2 + 88U);
    t14 = *((char **)t13);
    t16 = (t14 + 16U);
    xsi_wp_set_status(t16, 1);
    *((char **)t3) = &&LAB25;
    goto LAB1;

LAB25:    t4 = (t1 + 14160);
    t23 = *((int *)t4);
    *((int *)t4) = (t23 - 1);
    goto LAB22;

LAB26:    goto LAB6;

}

static void Initial_45_0(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(45, ng0);
    t1 = ((char*)((ng8)));
    t2 = (t0 + 6128);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 1);

LAB1:    return;
}

static void Always_47_1(char *t0)
{
    char t9[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    double t5;
    double t6;
    double t7;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;

LAB0:    t1 = (t0 + 10656U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(47, ng0);
    t2 = (t0 + 6768);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = *((double *)t4);
    t6 = (t5 / 2.0000000000000000);
    t6 = (t6 * 100.00000000000000);
    t7 = (t6 < 0.00000000000000000);
    if (t7 == 1)
        goto LAB4;

LAB5:    t6 = (t6 + 0.50000000000000000);
    t6 = ((int64)(t6));

LAB6:    t6 = (t6 * 10.000000000000000);
    t8 = (t0 + 10464);
    xsi_process_wait(t8, t6);
    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    t6 = 0.00000000000000000;
    goto LAB6;

LAB7:    xsi_set_current_line(47, ng0);
    t10 = (t0 + 6128);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memset(t9, 0, 8);
    t13 = (t12 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t12);
    t17 = (t16 & t15);
    t18 = (t17 & 1U);
    if (t18 != 0)
        goto LAB11;

LAB9:    if (*((unsigned int *)t13) == 0)
        goto LAB8;

LAB10:    t19 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t19) = 1;

LAB11:    t20 = (t9 + 4);
    t21 = (t12 + 4);
    t22 = *((unsigned int *)t12);
    t23 = (~(t22));
    *((unsigned int *)t9) = t23;
    *((unsigned int *)t20) = 0;
    if (*((unsigned int *)t21) != 0)
        goto LAB13;

LAB12:    t28 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t28 & 1U);
    t29 = *((unsigned int *)t20);
    *((unsigned int *)t20) = (t29 & 1U);
    t30 = (t0 + 6128);
    xsi_vlogvar_assign_value(t30, t9, 0, 0, 1);
    goto LAB2;

LAB8:    *((unsigned int *)t9) = 1;
    goto LAB11;

LAB13:    t24 = *((unsigned int *)t9);
    t25 = *((unsigned int *)t21);
    *((unsigned int *)t9) = (t24 | t25);
    t26 = *((unsigned int *)t20);
    t27 = *((unsigned int *)t21);
    *((unsigned int *)t20) = (t26 | t27);
    goto LAB12;

}

static void Initial_52_2(char *t0)
{
    char t18[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;

LAB0:    t1 = (t0 + 10904U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(52, ng0);

LAB4:    xsi_set_current_line(54, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 8368);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 16);
    xsi_set_current_line(60, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 6928);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(61, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 6288);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(62, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 6448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(64, ng0);
    t2 = ((char*)((ng28)));
    t3 = (t0 + 6608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 19);
    xsi_set_current_line(67, ng0);
    t2 = (t0 + 10712);
    t3 = (t0 + 2776);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB7:    t5 = (t0 + 10808);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB9:    if (t13 != 0)
        goto LAB10;

LAB5:    t6 = (t0 + 2776);
    xsi_vlog_subprogram_popinvocation(t6);

LAB6:    t14 = (t0 + 10808);
    t15 = *((char **)t14);
    t14 = (t0 + 2776);
    t16 = (t0 + 10712);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(70, ng0);
    xsi_set_current_line(70, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 8208);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB11:    t2 = (t0 + 8208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng35)));
    memset(t18, 0, 8);
    xsi_vlog_signed_less(t18, 32, t4, 32, t5, 32);
    t6 = (t18 + 4);
    t19 = *((unsigned int *)t6);
    t20 = (~(t19));
    t21 = *((unsigned int *)t18);
    t22 = (t21 & t20);
    t23 = (t22 != 0);
    if (t23 > 0)
        goto LAB12;

LAB13:    xsi_set_current_line(80, ng0);
    t2 = (t0 + 10712);
    t3 = (t0 + 2344);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB45:    t5 = (t0 + 10808);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB47:    if (t13 != 0)
        goto LAB48;

LAB43:    t6 = (t0 + 2344);
    xsi_vlog_subprogram_popinvocation(t6);

LAB44:    t14 = (t0 + 10808);
    t15 = *((char **)t14);
    t14 = (t0 + 2344);
    t16 = (t0 + 10712);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);

LAB1:    return;
LAB8:;
LAB10:    t5 = (t0 + 10904U);
    *((char **)t5) = &&LAB7;
    goto LAB1;

LAB12:    xsi_set_current_line(70, ng0);

LAB14:    xsi_set_current_line(71, ng0);
    t7 = ((char*)((ng7)));
    t8 = (t7 + 4);
    t24 = *((unsigned int *)t8);
    t25 = (~(t24));
    t26 = *((unsigned int *)t7);
    t13 = (t26 & t25);
    t9 = (t0 + 14164);
    *((int *)t9) = t13;

LAB15:    t10 = (t0 + 14164);
    if (*((int *)t10) > 0)
        goto LAB16;

LAB17:    xsi_set_current_line(72, ng0);
    t2 = (t0 + 10712);
    t3 = (t0 + 3208);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB21:    t5 = (t0 + 10808);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB23:    if (t13 != 0)
        goto LAB24;

LAB19:    t6 = (t0 + 3208);
    xsi_vlog_subprogram_popinvocation(t6);

LAB20:    t14 = (t0 + 10808);
    t15 = *((char **)t14);
    t14 = (t0 + 3208);
    t16 = (t0 + 10712);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(73, ng0);
    t2 = (t0 + 10712);
    t3 = (t0 + 4072);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB27:    t5 = (t0 + 10808);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB29:    if (t13 != 0)
        goto LAB30;

LAB25:    t6 = (t0 + 4072);
    xsi_vlog_subprogram_popinvocation(t6);

LAB26:    t14 = (t0 + 10808);
    t15 = *((char **)t14);
    t14 = (t0 + 4072);
    t16 = (t0 + 10712);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(74, ng0);
    t2 = (t0 + 10712);
    t3 = (t0 + 4504);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB33:    t5 = (t0 + 10808);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB35:    if (t13 != 0)
        goto LAB36;

LAB31:    t6 = (t0 + 4504);
    xsi_vlog_subprogram_popinvocation(t6);

LAB32:    t14 = (t0 + 10808);
    t15 = *((char **)t14);
    t14 = (t0 + 4504);
    t16 = (t0 + 10712);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(75, ng0);
    t2 = (t0 + 10712);
    t3 = (t0 + 4936);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB39:    t5 = (t0 + 10808);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB41:    if (t13 != 0)
        goto LAB42;

LAB37:    t6 = (t0 + 4936);
    xsi_vlog_subprogram_popinvocation(t6);

LAB38:    t14 = (t0 + 10808);
    t15 = *((char **)t14);
    t14 = (t0 + 4936);
    t16 = (t0 + 10712);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 8208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng7)));
    memset(t18, 0, 8);
    xsi_vlog_signed_add(t18, 32, t4, 32, t5, 32);
    xsi_vlogfile_write(1, 0, 0, ng36, 2, t0, (char)119, t18, 32);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 8208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng7)));
    memset(t18, 0, 8);
    xsi_vlog_signed_add(t18, 32, t4, 32, t5, 32);
    t6 = (t0 + 8208);
    xsi_vlogvar_assign_value(t6, t18, 0, 0, 32);
    goto LAB11;

LAB16:    xsi_set_current_line(71, ng0);
    t11 = (t0 + 11224);
    *((int *)t11) = 1;
    t12 = (t0 + 10936);
    *((char **)t12) = t11;
    *((char **)t1) = &&LAB18;
    goto LAB1;

LAB18:    t2 = (t0 + 14164);
    t13 = *((int *)t2);
    *((int *)t2) = (t13 - 1);
    goto LAB15;

LAB22:;
LAB24:    t5 = (t0 + 10904U);
    *((char **)t5) = &&LAB21;
    goto LAB1;

LAB28:;
LAB30:    t5 = (t0 + 10904U);
    *((char **)t5) = &&LAB27;
    goto LAB1;

LAB34:;
LAB36:    t5 = (t0 + 10904U);
    *((char **)t5) = &&LAB33;
    goto LAB1;

LAB40:;
LAB42:    t5 = (t0 + 10904U);
    *((char **)t5) = &&LAB39;
    goto LAB1;

LAB46:;
LAB48:    t5 = (t0 + 10904U);
    *((char **)t5) = &&LAB45;
    goto LAB1;

}


extern void work_m_00000000002922084254_3291669348_init()
{
	static char *pe[] = {(void *)Initial_45_0,(void *)Always_47_1,(void *)Initial_52_2};
	static char *se[] = {(void *)sp_PASS,(void *)sp_reset_signal_task,(void *)sp_random_task,(void *)sp_execution,(void *)sp_input_task,(void *)sp_wait_out_valid,(void *)sp_check_ans};
	xsi_register_didat("work_m_00000000002922084254_3291669348", "isim/PATTERN_isim_beh.exe.sim/work/m_00000000002922084254_3291669348.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
