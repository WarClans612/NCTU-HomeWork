The following files were generated for 'ten_divide' in directory
D:\mine\CAL\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * ten_divide.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * ten_divide.ngc
   * ten_divide.v
   * ten_divide.veo

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * ten_divide.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * ten_divide.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * ten_divide.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * ten_divide_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * ten_divide.gise
   * ten_divide.xise

Deliver Readme:
   Readme file for the IP.

   * ten_divide_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * ten_divide_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

