The following files were generated for 'divide_hundred' in directory
D:\mine\CAL\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * divide_hundred.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * divide_hundred.ngc
   * divide_hundred.v
   * divide_hundred.veo

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * divide_hundred.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * divide_hundred.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * divide_hundred.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * divide_hundred_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * divide_hundred.gise
   * divide_hundred.xise

Deliver Readme:
   Readme file for the IP.

   * divide_hundred_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * divide_hundred_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

